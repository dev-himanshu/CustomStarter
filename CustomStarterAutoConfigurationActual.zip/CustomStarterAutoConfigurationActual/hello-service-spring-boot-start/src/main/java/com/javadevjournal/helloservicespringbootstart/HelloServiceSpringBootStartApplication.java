package com.javadevjournal.helloservicespringbootstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloServiceSpringBootStartApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloServiceSpringBootStartApplication.class, args);
        System.out.println("hello-service-spring-boot-start-application started...");
    }

}
