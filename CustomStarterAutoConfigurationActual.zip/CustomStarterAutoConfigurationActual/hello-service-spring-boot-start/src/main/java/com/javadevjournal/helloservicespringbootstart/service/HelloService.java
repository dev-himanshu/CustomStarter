package com.javadevjournal.helloservicespringbootstart.service;

public interface HelloService {
    void sayHello();
}
