package com.javadevjournal.customapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
